@echo off
cd /d "%~dp0"
node "Serve Host.cjs"
if errorlevel 1 pause
