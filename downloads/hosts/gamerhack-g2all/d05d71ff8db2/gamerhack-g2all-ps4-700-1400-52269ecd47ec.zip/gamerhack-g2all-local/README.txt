GamerHack PS4 g2all offline host

Extract the complete ZIP. Use Node.js 20+ to run "Serve Host.cjs" or "Start Host.cmd" on your computer. Open the computer LAN URL shown by the host on the PS4. Use Save offline and wait for actual AppCache completion, close/reopen the console browser, then choose Load only on an exact supported firmware. No payload runs from the intro or cache page. Native execution/hardware success is not verified by this static package.

Firmware entries: 7.00, 7.01, 7.02, 7.50, 7.51, 7.55, 8.00, 8.01, 8.03, 8.50, 8.52, 9.00, 9.03, 9.04, 9.50, 9.51, 9.60, 10.00, 10.50, 11.00, 11.02, 11.50, 11.52, 12.00, 12.02, 12.50, 12.52, 13.00, 13.02, 13.04, 13.50, 13.52, 14.00. PS5 and the unrelated 5.05 branch are excluded. The upstream numeric dispatcher also routes 10.01/10.70/10.71 through nearest-lower CSS offset fallback; these are not exposed as exact-table matches.

Original repository: https://github.com/GamerHack/GamerHack.github.io
Commit: d05d71ff8db282f28cbc61f84c0a9588efacc451
Original script copyright and licence notices are retained. Native JS/BIN/ELF bytes are unchanged. No top-level blanket licence is asserted.
