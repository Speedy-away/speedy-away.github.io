Karo G2All Pro · GoldHEN 2.4b18.13
Extract the entire archive. With Node.js 20 or newer run node "Serve KARO.cjs" in this directory and open its displayed LAN address on a matching PS4 browser. Follow the original cache prompts. Native files are data and were not run during verification.
Source: https://github.com/KAR0218/KAR0218.github.io/tree/c72eaae8859476d4772e613d011db9f0bb80c80d/g2allpro
