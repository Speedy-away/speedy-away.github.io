/* Optional firmware-specific offline cache. Downloads bytes; never evaluates them. */
(function () {
 'use strict';
 var key='wwb.afterglow.1402.cache.enabled',toggle=document.getElementById('cache-enabled'),button=document.getElementById('cache-now'),stop=document.getElementById('cache-stop'),status=document.getElementById('cache-status'),progress=document.getElementById('cache-progress');
 var busy=false,ready=false,frame=null,worker=null,starting=false,listeners=[];
 function notify(){listeners.forEach(function(fn){fn();});}
 function state(text,loading,complete){status.textContent=text;busy=loading;ready=complete;button.disabled=loading;stop.disabled=!loading;progress.hidden=!loading;notify();}
 function supported(){try{return !!window.applicationCache||!!(navigator.serviceWorker&&window.isSecureContext);}catch(e){return false;}}
 function message(data){
  if(!data||data.type!=='afterglow-cache')return;
  if(data.state==='progress'){state('Saving files · '+data.loaded+' / '+data.total,true,false);if(data.total){progress.max=data.total;progress.value=data.loaded;}else progress.removeAttribute('value');}
  else if(data.state==='checking')state('Checking saved files…',true,ready);
  else if(data.state==='ready'){state('Cache ready · available offline',false,true);}
  else if(data.state==='empty')state('No saved offline copy yet',false,false);
  else if(data.state==='stopped')state('Caching stopped · retry when ready',false,false);
  else if(data.state==='error')state('Cache failed · '+(data.reason||'check your connection and retry'),false,false);
 }
 function cancel(){
  starting=false;
  if(frame){try{frame.contentWindow.applicationCache.abort();}catch(e){}frame.parentNode.removeChild(frame);frame=null;}
  if(worker)worker.postMessage({type:'afterglow-cache-stop'});
  state(ready?'Automatic caching off · saved copy retained':'Caching stopped · retry when ready',false,ready);
 }
 function appcache(){
  frame=document.createElement('iframe');frame.hidden=true;frame.title='Offline cache';frame.src='cache-frame.html';document.body.appendChild(frame);
 }
 function cacheNow(){
  if(busy||starting)return;
  if(!supported()){state('Offline caching is not supported by this browser',false,false);return;}
  starting=true;state('Preparing offline cache…',true,ready);
  if(window.applicationCache){appcache();starting=false;return;}
  navigator.serviceWorker.register('offline-sw.js',{scope:'./'}).then(function(reg){
   return new Promise(function(resolve,reject){var active=reg.active||reg.waiting||reg.installing;if(!active){reject(Error('Worker unavailable'));return;}if(active.state==='activated')return resolve(active);active.addEventListener('statechange',function(){if(active.state==='activated')resolve(active);else if(active.state==='redundant')reject(Error('Cache worker could not start'));});});
  }).then(function(active){worker=active;if(!starting)return;starting=false;worker.postMessage({type:'afterglow-cache-save'});}).catch(function(e){starting=false;state('Cache failed · '+e.message,false,false);});
 }
 window.addEventListener('message',function(event){if(frame&&event.source===frame.contentWindow&&event.origin===location.origin)message(event.data);});
 if(navigator.serviceWorker)navigator.serviceWorker.addEventListener('message',function(event){if(worker&&event.source===worker)message(event.data);});
 toggle.checked=false;try{toggle.checked=localStorage.getItem(key)==='true';}catch(e){}
 toggle.addEventListener('change',function(){try{localStorage.setItem(key,String(toggle.checked));}catch(e){}if(toggle.checked)cacheNow();else cancel();});
 button.addEventListener('click',cacheNow);stop.addEventListener('click',cancel);
 window.AfterglowCache={isBusy:function(){return busy;},isReady:function(){return ready;},subscribe:function(fn){listeners.push(fn);},stop:cancel};
 window.addEventListener('load',function(){if(toggle.checked)cacheNow();else state('Automatic caching off · use Cache now to save',false,false);});
 window.addEventListener('pagehide',function(){if(busy)cancel();});
}());
