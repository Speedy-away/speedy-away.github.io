/* Runtime-scoped immutable cache. Fetch and hash only; never execute payloads. */
'use strict';
const NAME='wwb-afterglow-1402-944d5aeed06f-v1',BASE=new URL('./',self.location.href).href,MARKER=BASE+'__complete__';
let running=false,cancelled=false;
self.addEventListener('install',event=>event.waitUntil(self.skipWaiting()));
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
const send=(client,state,fields={})=>client.postMessage({type:'afterglow-cache',state,...fields});
const digest=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),n=>n.toString(16).padStart(2,'0')).join('');
async function save(client){
 if(running)return;running=true;cancelled=false;
 try{
  send(client,'checking');const response=await fetch(BASE+'offline-files.json',{cache:'no-store'});if(!response.ok)throw Error('File list unavailable');
  const list=await response.json();if(!Array.isArray(list)||!list.length||list.length>80)throw Error('Invalid cache list');
  const cache=await caches.open(NAME);await cache.delete(MARKER);
  for(let i=0;i<list.length;i++){
   if(cancelled){send(client,'stopped');return;}
   const file=list[i];if(!/^[a-zA-Z0-9_.-]+$/.test(file.path)||!Number.isSafeInteger(file.bytes)||file.bytes<0||file.bytes>8*1024*1024||!/^\w{64}$/.test(file.sha256))throw Error('Invalid cache file');
   const url=BASE+file.path;let stored=await cache.match(url),bytes=stored&&await stored.arrayBuffer();
   if(!bytes||bytes.byteLength!==file.bytes||await digest(bytes)!==file.sha256){const result=await fetch(url,{cache:'no-store',redirect:'error'});if(!result.ok)throw Error('Download failed: '+file.path);bytes=await result.arrayBuffer();if(bytes.byteLength!==file.bytes||await digest(bytes)!==file.sha256)throw Error('Checksum mismatch: '+file.path);if(cancelled){send(client,'stopped');return;}await cache.put(url,new Response(bytes,{headers:result.headers}));}
   send(client,'progress',{loaded:i+1,total:list.length});
  }
  if(cancelled){send(client,'stopped');return;}
  await cache.put(MARKER,new Response(JSON.stringify(list.map(f=>f.path))));send(client,'ready');
 }catch(error){send(client,'error',{reason:error.message});}finally{running=false;}
}
self.addEventListener('message',event=>{if(!event.source||new URL(event.source.url).origin!==self.location.origin||!event.source.url.startsWith(BASE))return;if(event.data?.type==='afterglow-cache-save')event.waitUntil(save(event.source));else if(event.data?.type==='afterglow-cache-stop')cancelled=true;});
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);if(event.request.method!=='GET'||!url.href.startsWith(BASE))return;
 event.respondWith((async()=>{const cache=await caches.open(NAME),marker=await cache.match(MARKER);if(marker){const files=await marker.json(),name=url.pathname.slice(new URL(BASE).pathname.length)||'index.html';if(files.includes(name)){const cached=await cache.match(BASE+name);if(cached)return cached;}}return fetch(event.request);})());
});
