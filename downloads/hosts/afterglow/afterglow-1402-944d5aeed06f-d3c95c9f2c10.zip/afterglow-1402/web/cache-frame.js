/* AppCache-only bridge for PS4; no console modules are loaded. */
(function(){'use strict';var cache=window.applicationCache;
 function send(state,fields){var data={type:'afterglow-cache',state:state};Object.keys(fields||{}).forEach(function(k){data[k]=fields[k];});parent.postMessage(data,location.origin);}
 if(!cache){send('error',{reason:'AppCache unavailable'});return;}
 cache.addEventListener('checking',function(){send('checking');});
 cache.addEventListener('downloading',function(){send('progress',{loaded:0,total:0});});
 cache.addEventListener('progress',function(e){send('progress',{loaded:e.loaded,total:e.total});});
 ['cached','noupdate'].forEach(function(e){cache.addEventListener(e,function(){send('ready');});});
 cache.addEventListener('updateready',function(){try{cache.swapCache();}catch(e){}send('ready');});
 cache.addEventListener('error',function(){send('error',{reason:'connection or storage error; retry caching'});});
 cache.addEventListener('obsolete',function(){send('empty');});
 if(cache.status===1||cache.status===4)send('ready');
}());
