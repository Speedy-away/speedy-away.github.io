@echo off
cd /d "%~dp0"
node scripts\console-payload-bridge.cjs
pause
