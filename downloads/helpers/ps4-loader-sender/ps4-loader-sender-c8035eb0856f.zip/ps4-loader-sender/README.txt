PS4 loader sender
Requires Node.js 20+. Extract this ZIP into a new folder.
Windows: Start Sender.cmd. macOS/Linux: node scripts/console-payload-bridge.cjs
Open http://127.0.0.1:8766/hosts/ps4/loaders/ and enter the printed token.
Enable the HEN BIN loader on 9090. On 14.02, ELF HTTP starts the ELF service automatically when required. Select the console LAN address, firmware, loader and compatible file, then Send.
No payload is run on this computer. Custom files are held in memory, SHA-256 checked and sent once; they are not saved.
BIN 9090 and ELF 9021 are separate protocols. Raw BIN TCP9020 is pinned to PS4 9.00. Never use ELF mode for KARO BIN9021.
Transfer acceptance is not execution verification. No automatic retries. Ctrl+C stops the server.
WebKitty files: https://github.com/ArabPixel/WebKitty/tree/ff181af62e0c57d7b74b3ea40b7a166b21424864
