@echo off
cd /d "%~dp0"
node scripts/console-files-helper.cjs --lan
pause
